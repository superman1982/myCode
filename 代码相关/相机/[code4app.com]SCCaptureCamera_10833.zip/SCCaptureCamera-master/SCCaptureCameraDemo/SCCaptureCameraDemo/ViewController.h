//
//  ViewController.h
//  SCCaptureCameraDemo
//
//  Created by Aevitx on 14-1-18.
//  Copyright (c) 2014年 Aevitx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SCNavigationController.h"

@interface ViewController : UIViewController <SCNavigationControllerDelegate>

@end
