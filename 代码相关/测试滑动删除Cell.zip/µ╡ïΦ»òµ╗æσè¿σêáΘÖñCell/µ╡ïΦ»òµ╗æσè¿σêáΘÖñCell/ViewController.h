//
//  ViewController.h
//  测试滑动删除Cell
//
//  Created by lin on 14-8-7.
//  Copyright (c) 2014年 lin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomTableView.h"

@interface ViewController : UIViewController<CustomTableViewDataSource,CustomTableViewDelegate>

@property (nonatomic,retain) CustomTableView *customTableView;

@end
